# DermScan 개발 환경 설정
현재 작업 디렉토리: /home/ubuntu/dermscan
Python 3.10.12
pip 22.0.2 from /usr/lib/python3/dist-packages/pip (python 3.10)
v22.13.0
10.9.2
